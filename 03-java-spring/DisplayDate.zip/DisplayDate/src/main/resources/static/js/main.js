function alertPage(dt) {
	alert(`The ${dt} page was loaded`);
}