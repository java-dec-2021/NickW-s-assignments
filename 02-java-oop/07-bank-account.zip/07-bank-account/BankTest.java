public class BankTest {

    public static void main(String[] args) {
        BankAccount bank = new BankAccount();
        
    }

}