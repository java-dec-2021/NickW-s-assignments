public interface Ringable {
    String Ring();

    String unlock();
}