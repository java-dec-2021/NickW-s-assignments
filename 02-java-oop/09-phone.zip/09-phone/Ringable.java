public interface Ringable {
    // your code here
}